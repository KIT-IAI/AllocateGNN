"""Generator stage implementation."""

